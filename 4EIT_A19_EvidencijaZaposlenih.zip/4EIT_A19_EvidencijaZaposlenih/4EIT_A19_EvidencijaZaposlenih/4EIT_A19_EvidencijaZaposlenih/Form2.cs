﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A19_EvidencijaZaposlenih
{
    public partial class Form2 : Form
    {
        public int ID { get; set; }
        public string datum { get; set; }
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A19_EvidencijaZaposlenih;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            
            string Radnik = comboBox1.Text.ToString();
            string[] id = Radnik.Split('-');
            ID = Convert.ToInt32(id[0].Trim());
            datum = maskedTextBox1.Text.ToString();
            DialogResult = DialogResult.OK;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniComboBox();
        }
        private void PuniComboBox()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboNoviRukovodioc", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Radnik";

            Kon.Close();
        }
    }
}
