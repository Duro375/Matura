﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A7_FakultetskaEvidencija
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A7_FakultetskaEvidencija;Integrated Security=True");

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniDataGrid();
        }
        private void PuniDataGrid()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGrid", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();

            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;

            Kon.Close();
        }

        private void btnIzadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SaDataGridNaKontrole();
        }

        private void btnBrisi_Click(object sender, EventArgs e)
        {
            ObrisiPredmet();
            PuniDataGrid();
        }
        private void ObrisiPredmet()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("BrisiPredmet", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@PredmetID", SqlDbType.Int).Value = Convert.ToInt32(txtID.Text);

            cmd.ExecuteNonQuery();

            Kon.Close();
        }
        private void SaDataGridNaKontrole()
        {
            txtID.Text = Convert.ToString(dataGridView1.SelectedRows[0].Cells[0].Value);
            txtSifra.Text = Convert.ToString(dataGridView1.SelectedRows[0].Cells[1].Value);
            txtPredmet.Text = Convert.ToString(dataGridView1.SelectedRows[0].Cells[2].Value);
            txtSemestar.Text = Convert.ToString(dataGridView1.SelectedRows[0].Cells[3].Value);
            txtOpis.Text = Convert.ToString(dataGridView1.SelectedRows[0].Cells[4].Value);
        }
    }
}
