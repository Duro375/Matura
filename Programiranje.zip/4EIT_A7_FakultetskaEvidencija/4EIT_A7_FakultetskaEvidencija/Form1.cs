﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4EIT_A7_FakultetskaEvidencija
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 brisanje = new Form2();
            brisanje.ShowDialog();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            Form2 brisanje = new Form2();
            brisanje.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 analiza = new Form3();
            analiza.ShowDialog();
        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            Form3 analiza = new Form3();
            analiza.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
