﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A7_FakultetskaEvidencija
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A7_FakultetskaEvidencija;Integrated Security=True");

        private void Form3_Load(object sender, EventArgs e)
        {
            PuniCheckedLB();
        }
        private void PuniCheckedLB()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniCheckListBox", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();

            sda.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                checkedListBox1.Items.Add(dt.Rows[i]["Predmet"].ToString());
            }

            Kon.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniGridIChart();
        }
        private void PuniGridIChart()
        {
            chart1.Titles.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            int brojChecked = checkedListBox1.CheckedItems.Count;

            switch(brojChecked)
            {
                case 0:
                    MessageBox.Show("Molimo vas odaberite bar jedno polje");
                    break;
                case 1:
                    cmd.Parameters.AddWithValue("@Predmet1", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[0].ToString();
                    cmd.Parameters.AddWithValue("@Predmet2", SqlDbType.NVarChar).Value = "";
                    cmd.Parameters.AddWithValue("@Predmet3", SqlDbType.NVarChar).Value = "";
                    cmd.Parameters.AddWithValue("@Predmet4", SqlDbType.NVarChar).Value = "";
                    break;
                case 2:
                    cmd.Parameters.AddWithValue("@Predmet1", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[0].ToString();
                    cmd.Parameters.AddWithValue("@Predmet2", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[1].ToString();
                    cmd.Parameters.AddWithValue("@Predmet3", SqlDbType.NVarChar).Value = "";
                    cmd.Parameters.AddWithValue("@Predmet4", SqlDbType.NVarChar).Value = "";
                    break;
                case 3:
                    cmd.Parameters.AddWithValue("@Predmet1", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[0].ToString();
                    cmd.Parameters.AddWithValue("@Predmet2", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[1].ToString();
                    cmd.Parameters.AddWithValue("@Predmet3", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[2].ToString();
                    cmd.Parameters.AddWithValue("@Predmet4", SqlDbType.NVarChar).Value = "";
                    break;
                case 4:
                    cmd.Parameters.AddWithValue("@Predmet1", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[0].ToString();
                    cmd.Parameters.AddWithValue("@Predmet2", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[1].ToString();
                    cmd.Parameters.AddWithValue("@Predmet3", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[2].ToString();
                    cmd.Parameters.AddWithValue("@Predmet4", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[3].ToString();
                    break;
                    default:
                    MessageBox.Show("Molimo vas odaberite do 4 polja");
                    break;
            }

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;
            chart1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Predmet";
            chart1.Series["Series1"].YValueMembers = "2020";
            chart1.Series["Series1"].YValueMembers = "2021";
            chart1.Series["Series1"].YValueMembers = "2022";
            chart1.Titles.Add("Predmeti");

            Kon.Close();
        }
    }
}
