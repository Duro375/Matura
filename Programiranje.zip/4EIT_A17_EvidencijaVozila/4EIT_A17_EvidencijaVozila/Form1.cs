﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A17_EvidencijaVozila
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A17_EvidencijaVozila;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
            PuniComboModel();
            PuniComboBoja();
            PuniComboGorivo();
            btnOdustani.Visible = false;
            toolStripLabel1.Enabled = false;
        }
        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListBoxView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                ListViewItem item = new ListViewItem(dr[0].ToString());
                for(int i = 1; i < 11; i++)
                {
                    item.SubItems.Add(dr[i].ToString());
                }
                listView1.Items.Add(item);
            }

            Kon.Close();
        }
        private void PuniComboModel()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboModel", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboModel.DataSource = dt;
            comboModel.DisplayMember = "Naziv";

            Kon.Close();
        }
        private void PuniComboBoja()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboBoja", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboBoja.DataSource = dt;
            comboBoja.DisplayMember = "Naziv";

            Kon.Close();
        }
        private void PuniComboGorivo()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboGorivo", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboGorivo.DataSource = dt;
            comboGorivo.DisplayMember = "Naziv";

            Kon.Close();
        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPriprema_Click(object sender, EventArgs e)
        {
            btnOdustani.Visible = true;
            btnPriprema.Enabled = false;
            txtSifra.Enabled = false;
            toolStripLabel1.Enabled = true;
        }

        private void btnOdustani_Click(object sender, EventArgs e)
        {
            btnOdustani.Visible = false;
            btnPriprema.Enabled = true;
            txtSifra.Enabled = true;
            toolStripLabel1.Enabled = false;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void SaListViewNaKontrole()
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                txtSifra.Text = item.SubItems[0].Text;
                txtRegistracija.Text = item.SubItems[1].Text;
                txtGodina.Text = item.SubItems[2].Text;
                txtKM.Text = item.SubItems[3].Text;
                txtCena.Text = item.SubItems[7].Text;
                comboModel.Text = item.SubItems[4].Text + " - " + item.SubItems[8].Text;
                comboBoja.Text = item.SubItems[5].Text + " - " + item.SubItems[9].Text;
                comboGorivo.Text = item.SubItems[6].Text + " - " + item.SubItems[10].Text;
            }
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            IzmenaAutomobila();
            btnOdustani.Visible = false;
            btnPriprema.Enabled = true;
            txtSifra.Enabled = true;
            toolStripLabel1.Enabled = false;

        }
        private void IzmenaAutomobila()
        {
            try
            {
                Kon.Open();

                string Model = comboModel.Text.ToString();
                string[] ModelNaziv = Model.Split('-');
                string Boja = comboBoja.Text.ToString();
                string[] BojaNaziv = Boja.Split('-');
                string Gorivo = comboGorivo.Text.ToString();
                string[] GorivoNaziv = Gorivo.Split('-');



                SqlCommand cmd = new SqlCommand("AzurirajPodatkeVozilo", Kon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Registracija", SqlDbType.NVarChar).Value = txtRegistracija.Text.ToString();
                cmd.Parameters.AddWithValue("@GodinaProizvodnje", SqlDbType.Int).Value = Convert.ToInt32(txtGodina.Text);
                cmd.Parameters.AddWithValue("@Kilometraza", SqlDbType.Int).Value = Convert.ToInt32(txtKM.Text);
                cmd.Parameters.AddWithValue("@ModelNaziv", SqlDbType.NVarChar).Value = ModelNaziv[1].Trim();
                cmd.Parameters.AddWithValue("@BojaNaziv", SqlDbType.NVarChar).Value = BojaNaziv[1].Trim();
                if(GorivoNaziv[1].Trim() == "")
                {
                    cmd.Parameters.AddWithValue("@GorivoNaziv", SqlDbType.NVarChar).Value = "Benzin 95";
                }
                else
                {
                    cmd.Parameters.AddWithValue("@GorivoNaziv", SqlDbType.NVarChar).Value = GorivoNaziv[1].Trim();
                }
                cmd.Parameters.AddWithValue("@Cena", SqlDbType.NVarChar).Value = txtCena.Text.ToString();
                cmd.Parameters.AddWithValue("@VoziloID", SqlDbType.Int).Value = Convert.ToInt32(txtSifra.Text);

                cmd.ExecuteNonQuery();
                Kon.Close();
                //MessageBox.Show("Uspesno ste izmenili podatke", "Uspesna izmena");
                PuniListView();
            }
            catch (Exception)
            {
                MessageBox.Show("Desila se greska pri unosu");
            }
        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            Form2 analiza = new Form2();
            analiza.ShowDialog();
        }
    }
}
