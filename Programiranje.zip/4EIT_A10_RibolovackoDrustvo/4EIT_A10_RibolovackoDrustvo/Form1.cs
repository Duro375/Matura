﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A10_RibolovackoDrustvo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A10_RibolovackoDrustvo;Integrated Security=True");

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
            PuniComboGrad();
            txtSifra.Enabled = false;
        }
        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {
                ListViewItem item = new ListViewItem(dr[0].ToString());
                for(int i = 1; i < 6; i++)
                {
                    item.SubItems.Add(dr[i].ToString());
                }
                listView1.Items.Add(item);
            }

            Kon.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void SaListViewNaKontrole()
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                txtSifra.Text = item.SubItems[0].Text.ToString();
                txtIme.Text = item.SubItems[1].Text.ToString();
                txtPrezime.Text = item.SubItems[2].Text.ToString();
                comboGrad.Text = item.SubItems[4].Text.ToString();
                txtAdresa.Text = item.SubItems[3].Text.ToString();
                txtTelefon.Text = item.SubItems[5].Text.ToString();
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void PuniComboGrad()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboGrad", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboGrad.DataSource = dt;
            comboGrad.DisplayMember = "Grad";

            Kon.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            IzmeniPecarosa();
            PuniListView();
        }
        private void IzmeniPecarosa()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("IzmeniUpdatePecaros", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@PecarosID", SqlDbType.Int).Value = Convert.ToInt32(txtSifra.Text);
            cmd.Parameters.AddWithValue("@Ime", SqlDbType.NVarChar).Value = txtIme.Text.ToString();
            cmd.Parameters.AddWithValue("@Prezime", SqlDbType.NVarChar).Value = txtPrezime.Text.ToString();
            cmd.Parameters.AddWithValue("@Adresa", SqlDbType.NVarChar).Value = txtAdresa.Text.ToString();
            cmd.Parameters.AddWithValue("@Telefon", SqlDbType.NVarChar).Value = txtTelefon.Text.ToString();
            cmd.Parameters.AddWithValue("@Grad", SqlDbType.NVarChar).Value = comboGrad.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2();
            forma.ShowDialog();
        }
    }
}
