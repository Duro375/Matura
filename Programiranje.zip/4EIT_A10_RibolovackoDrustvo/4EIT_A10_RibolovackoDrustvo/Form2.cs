﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A10_RibolovackoDrustvo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A10_RibolovackoDrustvo;Integrated Security=True");

        private void btnIzadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniComboPecaros();
        }
        private void PuniComboPecaros()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboPecaros", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Pecaros";

            Kon.Close();
        }

        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            PuniGridIChart();
        }
        private void PuniGridIChart()
        {
            chart1.Titles.Clear();
            Kon.Open();
            string Pecaros = comboBox1.Text.ToString();
            string[] PecarosID = Pecaros.Split('-');
            SqlCommand cmd = new SqlCommand("PuniGridiChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@PecarosID", SqlDbType.Int).Value = PecarosID[0];
            cmd.Parameters.AddWithValue("@DatumOD", SqlDbType.NVarChar).Value = dateTimePicker1.Value;
            cmd.Parameters.AddWithValue("@DatumDO", SqlDbType.NVarChar).Value = dateTimePicker2.Value;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;
            chart1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Naziv";
            chart1.Series["Series1"].YValueMembers = "Broj";
            chart1.Titles.Add("Pecarosi");

            Kon.Close();
        }
    }
}
