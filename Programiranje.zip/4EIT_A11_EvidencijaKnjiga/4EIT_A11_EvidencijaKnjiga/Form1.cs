﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A11_EvidencijaKnjiga
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A11_EvidencijaKnjiga;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {
            btnUpisi.Enabled = false;
            btnOdustani.Enabled = false;
            PuniListView();
        }
        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {
                ListViewItem item = new ListViewItem(dr[0].ToString());
                for(int i = 1; i < 4; i++)
                {
                    item.SubItems.Add(dr[i].ToString());
                }
                listView1.Items.Add(item);
            }

            Kon.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void SaListViewNaKontrole()
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                txtSifra.Text = item.SubItems[0].Text.ToString();
                txtIme.Text = item.SubItems[1].Text.ToString();
                txtPrezime.Text = item.SubItems[2].Text.ToString();
                dtpDatum.Value = Convert.ToDateTime(item.SubItems[3].Text);
            }    
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            btnUpisi.Enabled = true;
            btnOdustani.Enabled = true;
            btnReset.Enabled = false;
            txtSifra.Enabled = false;
            txtSifra.Text = "";
            txtIme.Text = "";
            txtPrezime.Text = "";
            dtpDatum.Value = DateTime.Now;

        }

        private void btnOdustani_Click(object sender, EventArgs e)
        {
            btnUpisi.Enabled = false;
            btnOdustani.Enabled = false;
            btnReset.Enabled = true;
            txtSifra.Enabled = true;
            txtSifra.Text = "";
            txtIme.Text = "";
            txtPrezime.Text = "";
            dtpDatum.Value = DateTime.Now;
        }

        private void btnUpisi_Click(object sender, EventArgs e)
        {
            if(txtIme.Text == "" || txtPrezime.Text == "")
            {
                MessageBox.Show("Molimo vas popunite polja", "Greska u unosu");
            }
            else
            {
                UnesiAutora();
                PuniListView();
                btnUpisi.Enabled = false;
                btnOdustani.Enabled = false;
                btnReset.Enabled = true;
                txtSifra.Enabled = true;
                txtSifra.Text = "";
                txtIme.Text = "";
                txtPrezime.Text = "";
                dtpDatum.Value = DateTime.Now;
            }
            
        }
        private void UnesiAutora()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("InsertAutor", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ImeAutora", SqlDbType.NVarChar).Value = txtIme.Text.ToString();
            cmd.Parameters.AddWithValue("@PrezimeAutora", SqlDbType.NVarChar).Value = txtPrezime.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumRodjena", SqlDbType.Date).Value = dtpDatum.Value;

            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2();
            forma.ShowDialog();
        }
    }
}
