﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A5_ProduzeniBoravak
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A5_ProduzeniBoravak;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
        }
        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {
                ListViewItem item = new ListViewItem(dr[0].ToString());
                for(int i = 1; i < 5; i++)
                {
                    item.SubItems.Add(dr[i].ToString());
                }
                listView1.Items.Add(item);
            }

            Kon.Close();
        }

        private void btnIzadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void SaListViewNaKontrole()
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                txtSifra.Text = item.SubItems[0].Text.ToString();
                txtNaziv.Text = item.SubItems[1].Text.ToString();
                comboDan.Text = item.SubItems[2].Text.ToString();
                txtPocetak.Text = item.SubItems[3].Text.ToString();
                txtZavrsetak.Text = item.SubItems[4].Text.ToString();
            }
        }

        private void btnUnesi_Click(object sender, EventArgs e)
        {
            UnosAktivnosti();
            PuniListView();
        }
        private void UnosAktivnosti()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("UnesiAktivnost", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@NazivAktivnosti", SqlDbType.NVarChar).Value = txtNaziv.Text.ToString();
            cmd.Parameters.AddWithValue("@Dan", SqlDbType.NVarChar).Value = comboDan.Text.ToString();
            cmd.Parameters.AddWithValue("@Pocetak", SqlDbType.NVarChar).Value = txtPocetak.Text.ToString();
            cmd.Parameters.AddWithValue("@Zavrsetak", SqlDbType.NVarChar).Value = txtZavrsetak.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2();
            forma.ShowDialog();
        }
    }
}
