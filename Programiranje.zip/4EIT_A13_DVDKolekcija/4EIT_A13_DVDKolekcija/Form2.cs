﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A13_DVDKolekcija
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A13_DVDKolekcija;Integrated Security=True");
        private void btnIzadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            PuniGridIChart();
        }
        private void PuniGridIChart()
        {
            Kon.Open();
            
            chart1.Titles.Clear();

            SqlCommand cmd = new SqlCommand("PuniGridIChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;
            chart1.DataSource = dt;
            chart1.Series["Series1"].XValueMember = "Producent";
            chart1.Series["Series1"].YValueMembers = "BrojFilmova";
            chart1.Titles.Add("Broj filmova");

            Kon.Close();
        }
    }
}
