﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A13_DVDKolekcija
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A13_DVDKolekcija;Integrated Security=True");

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public int i = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
            txtSifra.Enabled = false;
        }
        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();
            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {
                if(i == 0)
                {
                    txtSifra.Text = dr[0].ToString();
                    txtIme.Text = dr[1].ToString();
                    txtEmail.Text = dr[2].ToString();
                }

                ListViewItem item = new ListViewItem(dr[0].ToString());
                item.SubItems.Add(dr[1].ToString());
                item.SubItems.Add(dr[2].ToString());
                listView1.Items.Add(item);

                i++;
            }

            Kon.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void SaListViewNaKontrole()
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                txtSifra.Text = item.SubItems[0].Text.ToString();
                txtIme.Text = item.SubItems[1].Text.ToString();
                txtEmail.Text = item.SubItems[2].Text.ToString();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            IzmeniProducenta();
            PuniListView();
        }
        private void IzmeniProducenta()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("IzmeniUpdate", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ProducentID", SqlDbType.Int).Value = Convert.ToInt32(txtSifra.Text);
            cmd.Parameters.AddWithValue("@Ime", SqlDbType.NVarChar).Value = txtIme.Text.ToString();
            cmd.Parameters.AddWithValue("@Email", SqlDbType.NVarChar).Value = txtEmail.Text.ToString(); 

            cmd.ExecuteNonQuery();

            MessageBox.Show("Uspesno ste zamenili podatke", "Uspesna izmena");

            Kon.Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2();
            forma.ShowDialog();
        }
    }
}
