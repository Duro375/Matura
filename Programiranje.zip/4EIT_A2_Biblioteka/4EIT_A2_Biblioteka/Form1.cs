﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A2_Biblioteka
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=EIT_А02_Biblioteka;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
        }
        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("SELECT AutorID, Ime, Prezime, DatumRodjenja FROM Autor", Kon);
            cmd.CommandType = CommandType.Text;

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ListViewItem item = new ListViewItem(dr[0].ToString());
                for(int i = 1; i < 4; i++)
                item.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(item);
            }    

            Kon.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void SaListViewNaKontrole()
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                txtSifra.Text = item.SubItems[0].Text;
                txtIme.Text = item.SubItems[1].Text;
                txtPrezime.Text = item.SubItems[2].Text;
                txtRodjen.Text = item.SubItems[3].Text;
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            BrisiAutor();
            PuniListView();
        }
        private void BrisiAutor()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("BrisiAutor", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@AutorID", SqlDbType.VarChar).Value = txtSifra.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.ShowDialog();
        }
    }
}
