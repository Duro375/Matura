﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A2_Biblioteka
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=EIT_А02_Biblioteka;Integrated Security=True");
        private void Form2_Load(object sender, EventArgs e)
        {
            PuniComboAutor();
        }
        private void PuniComboAutor()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboAutor", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboAutor.DataSource = dt;
            comboAutor.DisplayMember = "Autor";

            Kon.Close();
        }

        private void btnIzadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            PuniGridIChart();
        }
        private void PuniGridIChart()
        {
            string Autor = comboAutor.Text.ToString();
            string[] AutorID = Autor.Split('-');

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@SifraAutora", SqlDbType.NVarChar).Value = AutorID[0].Trim().ToString();
            cmd.Parameters.AddWithValue("@Period", SqlDbType.NVarChar).Value = numericUpDown1.Value;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;
            chart1.DataSource = dt;

            chart1.Series["Autori"].XValueMember = "GodUzimanja";
            chart1.Series["Autori"].YValueMembers = "BrIznajmljivanja";
            chart1.Titles.Add("Autori");

            Kon.Close();
        }
    }
}
