﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A16_IzlozbaPasa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection("Data Source=LAPTOP-U3UPVFJG\\MSSQLSERVER01;Initial Catalog=4EIT_A16_IzlozbaPasa;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {
            PuniComboPas();
            PuniComboIzlozba();
            PuniComboKategorija();
        }
        private void PuniComboPas()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboPas", Kon);
            cmd.CommandType = CommandType.StoredProcedure; 

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboPas.DataSource = dt;
            comboPas.DisplayMember = "Pas";

            Kon.Close();
        }
        private void PuniComboIzlozba()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboIzlozba", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboIzlozba.DataSource = dt;
            comboIzlozba.DisplayMember = "Izlozba";

            Kon.Close();
        }
        private void PuniComboKategorija()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboKategorija", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboKategorija.DataSource = dt;
            comboKategorija.DisplayMember = "Kategorija";

            Kon.Close();
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnZatvori_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrijava_Click(object sender, EventArgs e)
        {
            Provera();
        }
        private void Provera()
        {
            Kon.Open();

            string Pas = comboPas.Text.ToString();
            string[] PasID = Pas.Split('-');
            string Izlozba = comboIzlozba.Text.ToString();
            string[] IzlozbaID = Izlozba.Split('-');
            string Kategorija = comboKategorija.Text.ToString();
            string[] KategorijaID = Kategorija.Split('-');

            SqlCommand cmd = new SqlCommand("Provera", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.NVarChar).Value = IzlozbaID[0];
            cmd.Parameters.AddWithValue("@KategorijaID", SqlDbType.Int).Value = Convert.ToInt32(KategorijaID[0]);
            cmd.Parameters.AddWithValue("@PasID", SqlDbType.Int).Value = Convert.ToInt32(PasID[0]);

            string Pass = "";
            string Izlozbaa = "";
            string Kategorijaa = "";

            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pass = dr[2].ToString().Trim();
                Izlozbaa = dr[0].ToString().Trim();
                Kategorijaa = dr[1].ToString().Trim();
            }

            Kon.Close();

            if(PasID[0].Trim() == Pass && IzlozbaID[0].Trim() == Izlozbaa && KategorijaID[0].Trim() == Kategorijaa)
            {
                MessageBox.Show("Vec ste se prijavili", "Greska");
            }
            else
            {
                PrijaviPsa();
            }
        }
        private void PrijaviPsa()
        {
            Kon.Open();

            string Pas = comboPas.Text.ToString();
            string[] PasID = Pas.Split('-');
            string Izlozba = comboIzlozba.Text.ToString();
            string[] IzlozbaID = Izlozba.Split('-');
            string Kategorija = comboKategorija.Text.ToString();
            string[] KategorijaID = Kategorija.Split('-');

            SqlCommand cmd = new SqlCommand("PrijavaPasa", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.NVarChar).Value = IzlozbaID[0];
            cmd.Parameters.AddWithValue("@KategorijaID", SqlDbType.Int).Value = Convert.ToInt32(KategorijaID[0]);
            cmd.Parameters.AddWithValue("@PasID", SqlDbType.Int).Value = Convert.ToInt32(PasID[0]);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Uspesno ste se prijavili!");
            Kon.Close();
        }

        private void PuniComboIzlozba2()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboIzlozba", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboIzlozba2.DataSource = dt;
            comboIzlozba2.DisplayMember = "Izlozba";

            Kon.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PuniGridIChart()
        {
            chart1.Titles.Clear();
            string Izlozba = comboIzlozba2.Text.ToString();
            string[] IzlozbaID = Izlozba.Split('-');
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridIChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.NVarChar).Value = IzlozbaID[0];

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;
            chart1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Naziv";
            chart1.Series["Series1"].YValueMembers = "BrojPasa";
            chart1.Titles.Add("Broj pasa koji se takmicio");

            Kon.Close();
        }
        private void UkupanPrijavljen()
        {
            Kon.Open();

            string Izlozba = comboIzlozba2.Text.ToString();
            string[] IzlozbaID = Izlozba.Split('-');

            SqlCommand cmd = new SqlCommand("UkupanBrPrijavljenih", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.NVarChar).Value = IzlozbaID[0];

            SqlDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                label7.Text = "Ukupan broj pasa koji je prijavljen : " + dr[0].ToString();
            }

            Kon.Close();
        }

        private void tabPage2_Enter(object sender, EventArgs e)
        {
            PuniComboIzlozba2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniGridIChart();
            UkupanPrijavljen();
            UkupanTakmicen();
        }
        private void UkupanTakmicen()
        {
            Kon.Open();

            string Izlozba = comboIzlozba2.Text.ToString();
            string[] IzlozbaID = Izlozba.Split('-');

            SqlCommand cmd = new SqlCommand("UkupanBrKojiSeTakmicio", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.NVarChar).Value = IzlozbaID[0];

            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                label8.Text = "Ukupan broj pasa koji se takmicio : " + dr[0].ToString();
            }

            Kon.Close();
        }
    }
}
